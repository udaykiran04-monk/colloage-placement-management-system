Pictures for top performer students.
