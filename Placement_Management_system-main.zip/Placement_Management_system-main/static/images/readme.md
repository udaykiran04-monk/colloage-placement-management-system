This folder contains all pictures used in project
