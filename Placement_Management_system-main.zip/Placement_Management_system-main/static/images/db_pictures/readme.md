This folder contains all the profile pictures related to the project.
