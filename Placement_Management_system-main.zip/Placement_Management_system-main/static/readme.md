This file contains all the static files such as images/videos and also css files which are required in the project.
