Background images used in the project
