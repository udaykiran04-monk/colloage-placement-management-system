This folder is for storing cover letters
