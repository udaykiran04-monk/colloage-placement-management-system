This file contains all the html pages used in the project.
