# Placement_Management_system
This file contains all the front_end and Back_end files of the project. Please make sure to download these files in the same order as in the repository
